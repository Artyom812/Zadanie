﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Инд_зад_1_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inp = textBox1.Text;

            try
            {
                double res = Formula(inp);
                label1.Text = "Результат" + res;
            }
            catch (Exception ex)
            {
                label1.Text = "Ошибка: " + ex.Message;
            }
        }
        private double Formula(string formula)
        {
            formula = formula.Replace(" ", ""); //Удаление пробелов

            //Проверка на наличие равенства
            if (!formula.Contains("=")) 
                throw new InvalidOperationException("Некорректная формула");

            //Разбивание формулы на 2 части
            var pforms = formula.Split('=');
            if (pforms.Length != 2)
                throw new InvalidOperationException("Некорректная формула");

            string exp = pforms[1];
            return Expr(exp);
        }
        private double Expr(string exp)
        {
            Stack<double> stack = new Stack<double>();
            exp = exp.Replace("M(", "M|").Replace(")", "").Replace("m(", "m|"); //Удаление скобок

            string[] tok = exp.Split(new[] { '|', "," }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var toki in tok.Reverse())
            {
                if (double.TryParse(toki, out double num))
                {
                    stack.Push(num);
                }
                else if (toki.StartsWith("M"))
                {
                    double left = stack.Pop();
                    double right = stack.Pop();
                    stack.Push(Math.Max(left, right));
                }
                else if (toki.StartsWith("m"))
                {
                    double left = stack.Pop();
                    double right = stack.Pop();
                    stack.Push(Math.Max(left, right));
                }
            }
            return stack.Pop();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
