﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Инд_задания_1_Курдяков
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите префиксное выражение: "); //Писать все символы через пробел
            string ex = Console.ReadLine(); //Чтение префиксного выражения
            double res = Pref(ex);
            Console.WriteLine("Результат: " + res); //Пример: + A * B C = B*C+A
            Console.ReadKey();
        }
        static double Pref(string ex)
        {
            Stack<double> stack = new Stack<double>();
            string[] sim = ex.Split(' ');
            for (int i = sim.Length - 1; i >= 0; i--)
            {
                string simt = sim[i];
                if (double.TryParse(simt, out double num))
                {
                    stack.Push(num);
                }
                else
                {
                    double left = stack.Pop();
                    double right = stack.Pop();
                    double res = Oper(simt, left, right);
                    stack.Push(res);
                }
            }
            return stack.Pop();
        }
        static double Oper(string dor, double a, double b)
        {
            switch (dor)
            {
                case "+":
                    return a + b;
                case "-":
                    return a - b;
                case "*":
                    return a * b;
                case "/":
                    return a / b;
                default:
                    throw new InvalidOperationException("Неверный символ");
            }
        }
    }
}
