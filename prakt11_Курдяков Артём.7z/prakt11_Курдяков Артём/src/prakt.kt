import com.sun.tools.javac.Main
fun main() {
    display()
}
fun display() { //Перечисление дней недели
    println("\nДни недели: ")
    for (day in Day.values()) {
        println("${day.name}: ${day.dayNum}")
    }
    println("\nЦвета: ") //Перечисление цветов с их кодами
    for(color in Color.values()) {
        println("${color.name}: ${color.rgb}")
    }
    println("\nСтатусы заказа: ") //Перечисление статусов заказа
    for (status in Status.values()) {
        println("${status.name}: ${status.desc}")
    }
}