enum class Status(val desc: String) { //Статус заказа
    Ojidanie("Заказ в ожидании"),
    Progress("Заказ в процессе"),
    Compl("Заказ завершён"),
    Canc("Заказ отменён")
}